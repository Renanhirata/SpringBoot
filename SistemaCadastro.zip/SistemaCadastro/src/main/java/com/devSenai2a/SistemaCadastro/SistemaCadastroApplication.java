package com.devSenai2a.SistemaCadastro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCadastroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCadastroApplication.class, args);
	}

}
